"""Envelope address printing application."""

__version__ = "1.0.0"
