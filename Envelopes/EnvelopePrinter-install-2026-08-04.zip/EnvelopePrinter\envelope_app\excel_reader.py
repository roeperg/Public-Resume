"""Read recipient addresses from an Excel workbook."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from openpyxl import load_workbook

from .config import COLUMN_ALIASES


@dataclass(frozen=True)
class Address:
    """One recipient address row from the spreadsheet."""

    row: int  # 1-based Excel row number
    name: str
    address: str
    city: str
    state: str
    zip: str

    def city_state_zip(self) -> str:
        city = self.city.strip()
        state = self.state.strip()
        zip_code = self.zip.strip()
        left = ", ".join(part for part in (city, state) if part)
        if left and zip_code:
            return f"{left} {zip_code}"
        return left or zip_code

    def lines(self) -> list[str]:
        """Return non-empty address lines for printing."""
        result = []
        if self.name.strip():
            result.append(self.name.strip())
        if self.address.strip():
            result.append(self.address.strip())
        csz = self.city_state_zip()
        if csz:
            result.append(csz)
        return result

    def is_empty(self) -> bool:
        return not any(
            part.strip()
            for part in (self.name, self.address, self.city, self.state, self.zip)
        )


def _normalize_header(value: object) -> str:
    if value is None:
        return ""
    return str(value).strip().lower()


def _map_columns(headers: list[str]) -> dict[str, int]:
    """Map logical fields to 0-based column indexes."""
    mapping: dict[str, int] = {}
    for field, aliases in COLUMN_ALIASES.items():
        for index, header in enumerate(headers):
            if header in aliases:
                mapping[field] = index
                break
    required = ("name", "address", "city", "state", "zip")
    missing = [field for field in required if field not in mapping]
    if missing:
        raise ValueError(
            "Spreadsheet is missing required columns: "
            + ", ".join(missing)
            + ". Expected headers such as Name, Address, City, State, Zip."
        )
    return mapping


def load_addresses(path: str | Path, sheet_name: str | None = None) -> list[Address]:
    """
    Load addresses from the first sheet (or a named sheet).

    Row 1 is treated as the header. Data rows start at Excel row 2.
    Empty rows are skipped.
    """
    workbook = load_workbook(filename=str(path), read_only=True, data_only=True)
    try:
        sheet = workbook[sheet_name] if sheet_name else workbook.active
        rows = sheet.iter_rows(values_only=True)
        try:
            header_row = next(rows)
        except StopIteration as exc:
            raise ValueError("Spreadsheet is empty.") from exc

        headers = [_normalize_header(cell) for cell in header_row]
        columns = _map_columns(headers)
        addresses: list[Address] = []

        for excel_row, values in enumerate(rows, start=2):
            values = list(values) if values else []

            def cell(field: str) -> str:
                index = columns[field]
                if index >= len(values) or values[index] is None:
                    return ""
                return str(values[index]).strip()

            address = Address(
                row=excel_row,
                name=cell("name"),
                address=cell("address"),
                city=cell("city"),
                state=cell("state"),
                zip=cell("zip"),
            )
            if not address.is_empty():
                addresses.append(address)
        return addresses
    finally:
        workbook.close()


def slice_batch(
    addresses: list[Address],
    start_row: int,
    count: int,
) -> list[Address]:
    """
    Return up to `count` addresses whose Excel row is >= start_row.

    Addresses are already in sheet order.
    """
    if count < 1:
        raise ValueError("Number of addresses to print must be at least 1.")
    if start_row < 2:
        raise ValueError("Starting row must be 2 or greater (row 1 is the header).")

    selected = [addr for addr in addresses if addr.row >= start_row]
    return selected[:count]
