@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo  Envelope Printer — Installer
echo ============================================================
echo.
echo This installs a private Python environment in this folder
echo and the packages needed to run Envelope Printer.
echo.
echo Prerequisites:
echo   - Python 3.10+ on PATH  (python.org)
echo   - Microsoft Word installed  (used for printing)
echo.

where python >nul 2>&1
if errorlevel 1 (
  echo ERROR: Python was not found on PATH.
  echo Install Python 3.10+ from https://www.python.org/downloads/
  echo During setup, check "Add python.exe to PATH".
  echo.
  pause
  exit /b 1
)

for /f "tokens=*" %%V in ('python -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')"') do set PYVER=%%V
echo Found Python %PYVER%
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)"
if errorlevel 1 (
  echo ERROR: Python 3.10 or newer is required. Found %PYVER%.
  pause
  exit /b 1
)

if not exist "main.py" (
  echo ERROR: main.py not found. Run this installer from the EnvelopePrinter folder.
  pause
  exit /b 1
)
if not exist "requirements.txt" (
  echo ERROR: requirements.txt not found.
  pause
  exit /b 1
)

echo.
echo [1/4] Creating virtual environment (.venv) ...
if exist ".venv\Scripts\python.exe" (
  echo       Existing .venv found — reusing it.
) else (
  python -m venv .venv
  if errorlevel 1 (
    echo ERROR: Failed to create .venv
    pause
    exit /b 1
  )
)

echo [2/4] Upgrading pip ...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 (
  echo ERROR: pip upgrade failed.
  pause
  exit /b 1
)

echo [3/4] Installing dependencies (ttkbootstrap, openpyxl, python-docx, pywin32) ...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
  echo ERROR: Dependency install failed.
  pause
  exit /b 1
)

REM pywin32 sometimes needs a post-install step on fresh Windows setups.
if exist ".venv\Scripts\pywin32_postinstall.py" (
  echo       Running pywin32 post-install ...
  ".venv\Scripts\python.exe" ".venv\Scripts\pywin32_postinstall.py" -install >nul 2>&1
)

echo [4/4] Verifying installation ...
".venv\Scripts\python.exe" -c "import ttkbootstrap, openpyxl, docx, win32com.client, win32print; from envelope_app.gui import EnvelopeApp; from envelope_app.word_envelope import build_envelope_docx; print('OK')"
if errorlevel 1 (
  echo ERROR: Verification failed. See messages above.
  pause
  exit /b 1
)

echo.
echo Creating Desktop shortcut ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$dir = (Resolve-Path '%~dp0').Path; " ^
  "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$lnkPath = Join-Path $desktop 'Envelope Printer.lnk'; " ^
  "$w = New-Object -ComObject WScript.Shell; " ^
  "$s = $w.CreateShortcut($lnkPath); " ^
  "$s.TargetPath = Join-Path $dir 'run.bat'; " ^
  "$s.WorkingDirectory = $dir; " ^
  "$s.WindowStyle = 7; " ^
  "$s.Description = 'Envelope Printer'; " ^
  "$s.Save(); " ^
  "Write-Output ('Shortcut: ' + $lnkPath)"
if errorlevel 1 (
  echo WARNING: Could not create Desktop shortcut. You can still use run.bat.
)

echo.
echo ============================================================
echo  Installation complete.
echo ============================================================
echo.
echo To start Envelope Printer:
echo   - Double-click "Envelope Printer" on the Desktop, or
echo   - Double-click run.bat in this folder
echo.
echo Remember: Microsoft Word must be installed for printing.
echo.
pause
exit /b 0
