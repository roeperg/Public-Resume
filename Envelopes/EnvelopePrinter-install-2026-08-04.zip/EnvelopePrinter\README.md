# Envelope Printer

Python GUI for printing address envelopes from an Excel spreadsheet using **Microsoft Word** (Brother MFC-L8900CDW or any Windows printer).

## Features

- Browse and load an Excel file (`.xlsx`)
- Envelope sizes: **COM-10**, **Monarch**, **DL**, **C5**, plus US regulars **#5** through **#11**
- Editable return address
- Batch printing with **starting row** and **count**
- Session tracking: addresses printed and next unprinted Excel row
- **Preview Word** / **Print batch** via Microsoft Word
- Remembers last file, printer, return address, and progress

## Excel format (v1)

Row 1 is the header. Required columns (names are matched case-insensitively):

| Name | Address | City | State | Zip |
|------|---------|------|-------|-----|

Data begins on Excel row **2**.

## Install on another PC (Python already installed)

See **[INSTALL.md](INSTALL.md)** for the full GitHub download + install steps.

Short version:

1. Download the install zip from GitHub Releases (or the repo ZIP).
2. Extract it.
3. Run **`install.bat`**.
4. Start with the Desktop shortcut or **`run.bat`**.

Requires **Python 3.10+** and **Microsoft Word**.

### Create the install zip (maintainer)

```bat
pack_install.bat
```

Output: `release\EnvelopePrinter-install-YYYY-MM-DD.zip`

## Developer setup

```powershell
cd path\to\ENVELOPES
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python main.py
```

Or double-click `install.bat`, then `run.bat`.

## Optional standalone EXE

If you need a single EXE (no Python on the target PC):

```bat
build_exe.bat
```

Output: `dist\EnvelopePrinter.exe`  
Target PCs still need **Microsoft Word** for printing.

## Printing tips

1. Load envelopes in the Brother **MP tray** (about 10 at a time).
2. Set paper size / type on the printer or in the driver to match.
3. Use a batch size of **10 or fewer** to match tray capacity.
4. After each batch, the GUI advances **Next unprinted row**.

## Project layout

```
ENVELOPES/
  install.bat             # install deps into .venv (for GitHub installs)
  uninstall.bat
  run.bat                 # launch the app
  pack_install.bat        # build release zip for GitHub
  INSTALL.md              # end-user install instructions
  main.py
  requirements.txt
  envelope_app/
    config.py
    excel_reader.py
    word_envelope.py      # Word document build + print
    printers.py
    gui.py
```
