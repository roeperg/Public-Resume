@echo off
setlocal EnableExtensions
cd /d "%~dp0"

echo ============================================================
echo  Envelope Printer — Uninstaller
echo ============================================================
echo.
echo This removes the local Python environment (.venv) and the
echo Desktop shortcut. Source files are left in place.
echo.
set /p CONFIRM=Type YES to uninstall: 
if /I not "%CONFIRM%"=="YES" (
  echo Cancelled.
  pause
  exit /b 0
)

taskkill /IM EnvelopePrinter.exe /F >nul 2>&1

echo Removing .venv ...
if exist ".venv" rmdir /s /q ".venv"

echo Removing Desktop shortcut ...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$desktop = [Environment]::GetFolderPath('Desktop'); " ^
  "$lnk = Join-Path $desktop 'Envelope Printer.lnk'; " ^
  "if (Test-Path $lnk) { Remove-Item $lnk -Force; Write-Output 'Removed shortcut.' } else { Write-Output 'No shortcut found.' }"

echo.
echo Uninstall finished.
pause
exit /b 0
