"""Windows printer discovery helpers (no PDF/Word dependencies)."""

from __future__ import annotations

from .config import PREFERRED_PRINTER_SUBSTRINGS

try:
    import win32print
except ImportError:  # pragma: no cover
    win32print = None


def list_printers() -> list[str]:
    """Return installed Windows printer names."""
    if win32print is None:
        return []
    flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
    printers = win32print.EnumPrinters(flags, None, 2)
    return [printer["pPrinterName"] for printer in printers]


def default_printer() -> str:
    if win32print is None:
        return ""
    try:
        return win32print.GetDefaultPrinter()
    except Exception:
        return ""


def preferred_printer(names: list[str] | None = None) -> str:
    """Pick a Brother MFC-L8900-like printer when available."""
    printers = names if names is not None else list_printers()
    lowered = [(name, name.lower()) for name in printers]
    for needle in PREFERRED_PRINTER_SUBSTRINGS:
        for name, low in lowered:
            if needle in low:
                return name
    return default_printer() or (printers[0] if printers else "")
