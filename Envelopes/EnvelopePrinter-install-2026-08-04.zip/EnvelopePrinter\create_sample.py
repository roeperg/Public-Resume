"""Create a sample address workbook for testing."""

from pathlib import Path

from openpyxl import Workbook


SAMPLES = [
    ("Alice Johnson", "100 Oak Avenue", "Springfield", "IL", "62701"),
    ("Bob Smith", "45 River Road", "Madison", "WI", "53703"),
    ("Carlos Rivera", "890 Pine Street", "Austin", "TX", "78701"),
    ("Dana Lee", "12 Lake View Dr", "Portland", "OR", "97201"),
    ("Evan Brooks", "550 Market St Apt 4B", "Denver", "CO", "80202"),
    ("Fiona Chen", "77 Harbor Blvd", "Seattle", "WA", "98101"),
    ("Gabe Ortiz", "301 College Ave", "Ann Arbor", "MI", "48104"),
    ("Hannah Patel", "9 Crescent Court", "Nashville", "TN", "37203"),
    ("Ian Murphy", "640 Elm Street", "Boston", "MA", "02108"),
    ("Julia Nguyen", "18 Sunset Lane", "San Diego", "CA", "92101"),
    ("Kevin Walsh", "222 Birch Road", "Minneapolis", "MN", "55401"),
    ("Laura Kim", "15 Willow Way", "Raleigh", "NC", "27601"),
]


def main() -> None:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Addresses"
    sheet.append(["Name", "Address", "City", "State", "Zip"])
    for row in SAMPLES:
        sheet.append(list(row))

    out = Path(__file__).resolve().parent / "sample_addresses.xlsx"
    workbook.save(out)
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
