"""Modern ttkbootstrap GUI for envelope batch printing."""

from __future__ import annotations

import inspect
import json
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

import ttkbootstrap as ttk
from ttkbootstrap.constants import BOTH, LEFT, RIGHT, X, YES

try:
    # ttkbootstrap 2.x
    from ttkbootstrap import ScrolledText, ToolTip
except ImportError:
    # ttkbootstrap 1.x
    from ttkbootstrap.scrolled import ScrolledText
    from ttkbootstrap.tooltip import ToolTip

from .config import (
    DEFAULT_ENVELOPE,
    ENVELOPE_KEYS_BY_LABEL,
    ENVELOPE_LABELS,
    ENVELOPE_SIZES,
    settings_path,
)
from .excel_reader import Address, load_addresses, slice_batch
from .logo_data import LOGO_PNG_BASE64
from .printers import list_printers, preferred_printer
from .word_envelope import (
    preview_envelopes_word,
    print_envelopes_word,
    word_layout_for_size,
)


class EnvelopeApp(ttk.Window):
    """Main application window."""

    def __init__(self) -> None:
        super().__init__(
            title="Envelope Printer",
            themename="cosmo",
            size=(860, 960),
            minsize=(780, 720),
        )

        self.addresses: list[Address] = []
        self.total_printed = 0
        self.next_row = 2
        self._busy = False

        self.excel_path = tk.StringVar()
        self.envelope_size = tk.StringVar(value=DEFAULT_ENVELOPE)
        self.printer_name = tk.StringVar()
        self.start_row = tk.IntVar(value=2)
        self.batch_count = tk.IntVar(value=10)
        self.status_total = tk.StringVar(value="—")
        self.status_printed = tk.StringVar(value="0")
        self.status_next = tk.StringVar(value="2")
        self.status_remaining = tk.StringVar(value="—")
        self.status_message = tk.StringVar(value="Choose an Excel file to begin.")

        self._build_ui()
        self._fit_window()
        self._load_settings()
        self._refresh_printers()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    def _fit_window(self) -> None:
        """Size the window so action buttons and status text are visible."""
        self.update_idletasks()
        req_w = max(self.winfo_reqwidth() + 24, 860)
        req_h = max(self.winfo_reqheight() + 40, 960)
        screen_w = self.winfo_screenwidth()
        screen_h = self.winfo_screenheight()
        width = min(req_w, max(screen_w - 40, 780))
        height = min(req_h, max(screen_h - 80, 720))
        self.minsize(780, min(height, 720))
        self.geometry(f"{width}x{height}")
        self.place_window_center()

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=20)
        outer.pack(fill=BOTH, expand=YES)

        header = ttk.Frame(outer)
        header.pack(fill=X, pady=(0, 16))

        title_col = ttk.Frame(header)
        title_col.pack(side=LEFT, fill=X, expand=YES)
        ttk.Label(
            title_col,
            text="Envelope Printer",
            font=("Segoe UI Semibold", 22),
            bootstyle="primary",
        ).pack(anchor="w")

        self._logo_image = tk.PhotoImage(data=LOGO_PNG_BASE64).zoom(2, 2)
        logo_label = ttk.Label(header, image=self._logo_image)
        logo_label.pack(side=RIGHT, padx=(12, 0))

        self._section_file(outer)
        self._section_printer(outer)
        self._section_envelope(outer)
        self._section_return(outer)
        self._section_batch(outer)
        self._section_status(outer)
        self._section_actions(outer)

        footer = ttk.Frame(outer)
        footer.pack(fill=X, pady=(16, 0))
        ttk.Label(
            footer,
            textvariable=self.status_message,
            font=("Segoe UI", 9),
            bootstyle="secondary",
        ).pack(side=LEFT)

    def _card(self, parent: ttk.Frame, title: str) -> ttk.Labelframe:
        frame = ttk.Labelframe(parent, text=f"  {title}  ", padding=14, bootstyle="primary")
        frame.pack(fill=X, pady=(0, 12))
        return frame

    def _section_file(self, parent: ttk.Frame) -> None:
        card = self._card(parent, "Address file")
        row = ttk.Frame(card)
        row.pack(fill=X)

        entry = ttk.Entry(row, textvariable=self.excel_path)
        entry.pack(side=LEFT, fill=X, expand=YES, padx=(0, 8))
        ToolTip(entry, text="Excel workbook with Name, Address, City, State, Zip columns")

        browse = ttk.Button(
            row,
            text="Browse…",
            bootstyle="secondary-outline",
            command=self._browse_excel,
            width=12,
        )
        browse.pack(side=LEFT, padx=(0, 8))

        load_btn = ttk.Button(
            row,
            text="Load",
            bootstyle="primary",
            command=self._load_excel,
            width=10,
        )
        load_btn.pack(side=LEFT)

    def _section_printer(self, parent: ttk.Frame) -> None:
        card = self._card(parent, "Printer")
        printer_row = ttk.Frame(card)
        printer_row.pack(fill=X)
        ttk.Label(printer_row, text="Printer", width=10).pack(side=LEFT)
        self.printer_combo = ttk.Combobox(
            printer_row,
            textvariable=self.printer_name,
            state="readonly",
            values=[],
        )
        self.printer_combo.pack(side=LEFT, fill=X, expand=YES, padx=(0, 8))
        ToolTip(self.printer_combo, text="Choose the Windows printer for envelopes")
        ttk.Button(
            printer_row,
            text="Refresh",
            bootstyle="secondary-outline",
            command=self._refresh_printers,
            width=10,
        ).pack(side=LEFT)

    def _section_envelope(self, parent: ttk.Frame) -> None:
        card = self._card(parent, "Envelope size")
        row = ttk.Frame(card)
        row.pack(fill=X)
        ttk.Label(row, text="Size", width=10).pack(side=LEFT)
        self.envelope_combo = ttk.Combobox(
            row,
            state="readonly",
            values=list(ENVELOPE_LABELS.values()),
        )
        self.envelope_combo.pack(side=LEFT, fill=X, expand=YES)
        self.envelope_combo.set(ENVELOPE_LABELS[self.envelope_size.get()])
        self.envelope_combo.bind("<<ComboboxSelected>>", self._on_envelope_selected)
        ToolTip(self.envelope_combo, text="Page size used for the Word envelope document")

    def _on_envelope_selected(self, _event=None) -> None:
        label = self.envelope_combo.get()
        key = ENVELOPE_KEYS_BY_LABEL.get(label)
        if not key:
            return
        if key == self.envelope_size.get():
            return
        self.envelope_size.set(key)
        self._save_settings()

    def _section_return(self, parent: ttk.Frame) -> None:
        card = self._card(parent, "Return address")
        # ttkbootstrap 1.x uses autohide; 2.x uses auto_hide
        scrolled_kwargs = {"height": 4, "padding": 4}
        params = inspect.signature(ScrolledText.__init__).parameters
        if "auto_hide" in params:
            scrolled_kwargs["auto_hide"] = True
        else:
            scrolled_kwargs["autohide"] = True
        self.return_text = ScrolledText(card, **scrolled_kwargs)
        self.return_text.pack(fill=X)
        self.return_text.insert(
            "1.0",
            "Your Name\n123 Main Street\nCity, ST 12345",
        )
        ToolTip(self.return_text, text="Printed in the upper-left of each envelope")

    def _section_batch(self, parent: ttk.Frame) -> None:
        card = self._card(parent, "Batch")
        grid = ttk.Frame(card)
        grid.pack(fill=X)

        ttk.Label(grid, text="Starting row").grid(row=0, column=0, sticky="w", padx=(0, 8))
        start = ttk.Spinbox(
            grid,
            from_=2,
            to=1_000_000,
            textvariable=self.start_row,
            width=10,
            command=self._on_batch_fields_changed,
        )
        start.grid(row=0, column=1, sticky="w", padx=(0, 24))
        start.bind("<KeyRelease>", lambda _e: self._on_batch_fields_changed())
        ToolTip(start, text="Excel row number to begin printing (header is row 1)")

        ttk.Label(grid, text="Addresses to print").grid(
            row=0, column=2, sticky="w", padx=(0, 8)
        )
        count = ttk.Spinbox(
            grid,
            from_=1,
            to=500,
            textvariable=self.batch_count,
            width=10,
            command=self._on_batch_fields_changed,
        )
        count.grid(row=0, column=3, sticky="w")
        count.bind("<KeyRelease>", lambda _e: self._on_batch_fields_changed())
        ToolTip(count, text="How many envelopes to print in this batch")

        tip = ttk.Label(
            card,
            text="Tip: Brother MP tray holds about 10 envelopes — print in small batches.",
            bootstyle="secondary",
            font=("Segoe UI", 9),
        )
        tip.pack(anchor="w", pady=(10, 0))

    def _section_status(self, parent: ttk.Frame) -> None:
        card = self._card(parent, "Progress")
        stats = ttk.Frame(card)
        stats.pack(fill=X)

        self._stat(stats, "Loaded addresses", self.status_total, 0)
        self._stat(stats, "Printed this session", self.status_printed, 1)
        self._stat(stats, "Next unprinted row", self.status_next, 2)
        self._stat(stats, "Remaining", self.status_remaining, 3)

        for col in range(4):
            stats.columnconfigure(col, weight=1)

    def _stat(
        self,
        parent: ttk.Frame,
        label: str,
        variable: tk.StringVar,
        column: int,
    ) -> None:
        box = ttk.Frame(parent, padding=(8, 6))
        box.grid(row=0, column=column, sticky="nsew", padx=4)
        ttk.Label(box, text=label, bootstyle="secondary", font=("Segoe UI", 9)).pack(
            anchor="w"
        )
        ttk.Label(
            box,
            textvariable=variable,
            font=("Segoe UI Semibold", 18),
            bootstyle="primary",
        ).pack(anchor="w")

    def _section_actions(self, parent: ttk.Frame) -> None:
        row = ttk.Frame(parent)
        row.pack(fill=X, pady=(4, 0))

        self.print_btn = ttk.Button(
            row,
            text="Print batch",
            bootstyle="success",
            command=self._print_batch,
            width=16,
        )
        self.print_btn.pack(side=RIGHT)

        self.preview_btn = ttk.Button(
            row,
            text="Preview Word",
            bootstyle="info-outline",
            command=self._preview_batch,
            width=14,
        )
        self.preview_btn.pack(side=RIGHT, padx=(0, 8))

        ttk.Button(
            row,
            text="Reset progress",
            bootstyle="warning-outline",
            command=self._reset_progress,
            width=14,
        ).pack(side=LEFT)

    # -------------------------------------------------------------- settings
    def _load_settings(self) -> None:
        path = settings_path()
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return

        if data.get("excel_path"):
            self.excel_path.set(data["excel_path"])
        if data.get("envelope_size") in ENVELOPE_SIZES:
            key = data["envelope_size"]
            self.envelope_size.set(key)
            self.envelope_combo.set(ENVELOPE_LABELS[key])
        if data.get("printer_name"):
            self.printer_name.set(data["printer_name"])
        if data.get("return_address"):
            self.return_text.delete("1.0", "end")
            self.return_text.insert("1.0", data["return_address"])
        if data.get("batch_count"):
            self.batch_count.set(int(data["batch_count"]))
        if data.get("next_row"):
            self.next_row = int(data["next_row"])
            self.start_row.set(self.next_row)
            self.status_next.set(str(self.next_row))
        if data.get("total_printed") is not None:
            self.total_printed = int(data["total_printed"])
            self.status_printed.set(str(self.total_printed))

        if self.excel_path.get() and Path(self.excel_path.get()).exists():
            try:
                self._load_excel(silent=True)
            except Exception:
                pass

    def _save_settings(self) -> None:
        data = {
            "excel_path": self.excel_path.get(),
            "envelope_size": self.envelope_size.get(),
            "printer_name": self.printer_name.get(),
            "return_address": self.return_text.get("1.0", "end").strip(),
            "batch_count": self.batch_count.get(),
            "next_row": self.next_row,
            "total_printed": self.total_printed,
        }
        try:
            settings_path().write_text(
                json.dumps(data, indent=2), encoding="utf-8"
            )
        except OSError:
            pass

    # -------------------------------------------------------------- actions
    def _browse_excel(self) -> None:
        path = filedialog.askopenfilename(
            title="Select address spreadsheet",
            filetypes=[
                ("Excel files", "*.xlsx *.xlsm *.xltx *.xltm"),
                ("All files", "*.*"),
            ],
        )
        if path:
            self.excel_path.set(path)
            self._load_excel()

    def _load_excel(self, silent: bool = False) -> None:
        path = self.excel_path.get().strip()
        if not path:
            if not silent:
                messagebox.showwarning("Missing file", "Please choose an Excel file.")
            return
        if not Path(path).exists():
            if not silent:
                messagebox.showerror("File not found", f"Cannot find:\n{path}")
            return
        try:
            self.addresses = load_addresses(path)
        except Exception as exc:
            if not silent:
                messagebox.showerror("Load failed", str(exc))
            self.status_message.set(f"Load failed: {exc}")
            return

        self.status_total.set(str(len(self.addresses)))
        self._update_remaining()
        self.status_message.set(
            f"Loaded {len(self.addresses)} address(es) from {Path(path).name}"
        )
        self._save_settings()

    def _refresh_printers(self) -> None:
        printers = list_printers()
        self.printer_combo.configure(values=printers)
        current = self.printer_name.get()
        if current and current in printers:
            return
        self.printer_name.set(preferred_printer(printers))

    def _return_address(self) -> str:
        return self.return_text.get("1.0", "end").strip()

    def _selected_batch(self) -> list[Address]:
        if not self.addresses:
            raise ValueError("Load an Excel file first.")
        start = int(self.start_row.get())
        count = int(self.batch_count.get())
        batch = slice_batch(self.addresses, start, count)
        if not batch:
            raise ValueError(
                f"No addresses found at or after row {start}."
            )
        return batch

    def _on_batch_fields_changed(self) -> None:
        self._update_remaining()

    def _update_remaining(self) -> None:
        if not self.addresses:
            self.status_remaining.set("—")
            return
        try:
            start = int(self.start_row.get())
        except (tk.TclError, ValueError, TypeError):
            self.status_remaining.set("—")
            return
        remaining = sum(1 for addr in self.addresses if addr.row >= start)
        self.status_remaining.set(str(remaining))

    def _set_busy(self, busy: bool) -> None:
        self._busy = busy
        state = "disabled" if busy else "normal"
        self.print_btn.configure(state=state)
        self.preview_btn.configure(state=state)

    def _format_batch_preview(self, batch: list[Address]) -> str:
        lines = [f"Row {batch[0].row}: {batch[0].name}"]
        for part in batch[0].lines()[1:]:
            lines.append(f"  {part}")
        if len(batch) > 1:
            lines.append(f"  … plus {len(batch) - 1} more")
        return "\n".join(lines)

    def _preview_batch(self) -> None:
        if self._busy:
            return
        try:
            batch = self._selected_batch()
            return_address = self._return_address()
            if not return_address:
                raise ValueError("Enter a return address.")
            envelope_key = self.envelope_size.get()
            layout = word_layout_for_size(envelope_key)
            path = preview_envelopes_word(batch, return_address, envelope_key)
            self.status_message.set(
                f"Word preview opened ({len(batch)} envelope(s)): {path.name}  "
                f'| indent {float(layout["recipient_indent_in"]):.2f}"  '
                f'| blanks {layout["blank_lines"]}'
            )
        except Exception as exc:
            messagebox.showerror("Preview failed", str(exc))

    def _print_batch(self) -> None:
        if self._busy:
            return
        try:
            batch = self._selected_batch()
            printer = self.printer_name.get().strip()
            if not printer:
                raise ValueError("Select a printer.")
            return_address = self._return_address()
            if not return_address:
                raise ValueError("Enter a return address.")
            # Capture all Tk values on the main thread before background work.
            envelope_key = self.envelope_size.get()
            layout = word_layout_for_size(envelope_key)
        except Exception as exc:
            messagebox.showerror("Cannot print", str(exc))
            return

        rows = f"{batch[0].row}–{batch[-1].row}"
        confirm = messagebox.askyesno(
            "Confirm print",
            f"Print {len(batch)} envelope(s) via Microsoft Word\n"
            f"(Excel rows {rows})\n"
            f"Size: {ENVELOPE_SIZES[envelope_key]['label']}\n"
            f'Page: {float(layout["width_in"]):.3f}" × '
            f'{float(layout["height_in"]):.3f}" landscape, '
            f'{float(layout["margin_in"]):.2f}" margins\n'
            f'Recipient indent: {float(layout["recipient_indent_in"]):.2f}"  |  '
            f'blank lines: {layout["blank_lines"]}\n'
            f"Printer: {printer}\n\n"
            f"First envelope:\n{self._format_batch_preview(batch)}\n\n"
            "Load envelopes in the MP tray before continuing.",
        )
        if not confirm:
            return

        self._set_busy(True)
        self.status_message.set(
            f"Printing {len(batch)} envelope(s) via Word…"
        )

        def worker() -> None:
            try:
                docx_path = print_envelopes_word(
                    batch,
                    return_address,
                    envelope_key,
                    printer,
                )
            except Exception as exc:
                self.after(0, lambda err=exc: self._on_print_error(err))
                return
            self.after(
                0,
                lambda addrs=batch, path=docx_path: self._on_print_success(
                    addrs, path
                ),
            )

        threading.Thread(target=worker, daemon=True).start()

    def _on_print_success(self, batch: list[Address], docx_path: Path) -> None:
        self.total_printed += len(batch)
        last_row = batch[-1].row
        following = [addr.row for addr in self.addresses if addr.row > last_row]
        self.next_row = following[0] if following else last_row + 1
        self.start_row.set(self.next_row)
        self.status_printed.set(str(self.total_printed))
        self.status_next.set(str(self.next_row))
        self._update_remaining()
        self.status_message.set(
            f"Printed {len(batch)} envelope(s) via Word. Next row: {self.next_row}"
        )
        self._set_busy(False)
        self._save_settings()
        messagebox.showinfo(
            "Batch complete",
            f"Printed {len(batch)} envelope(s) via Microsoft Word.\n"
            f"Session total: {self.total_printed}\n"
            f"Next unprinted row: {self.next_row}\n\n"
            f"Saved copy: {docx_path}",
        )

    def _on_print_error(self, exc: Exception) -> None:
        self._set_busy(False)
        self.status_message.set(f"Print failed: {exc}")
        messagebox.showerror("Print failed", str(exc))

    def _reset_progress(self) -> None:
        if not messagebox.askyesno(
            "Reset progress",
            "Reset printed count and next row back to the start of the list?",
        ):
            return
        self.total_printed = 0
        self.next_row = self.addresses[0].row if self.addresses else 2
        self.start_row.set(self.next_row)
        self.status_printed.set("0")
        self.status_next.set(str(self.next_row))
        self._update_remaining()
        self.status_message.set("Progress reset.")
        self._save_settings()

    def _on_close(self) -> None:
        self._save_settings()
        self.destroy()


def run() -> None:
    app = EnvelopeApp()
    app.mainloop()
