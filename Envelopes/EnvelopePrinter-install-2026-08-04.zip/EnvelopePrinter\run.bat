@echo off
setlocal EnableExtensions
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
  echo Envelope Printer is not installed yet.
  echo.
  echo Run install.bat first (requires Python 3.10+ and Microsoft Word).
  echo.
  pause
  exit /b 1
)

start "" ".venv\Scripts\pythonw.exe" main.py
if errorlevel 1 (
  echo Launch with pythonw failed — trying python.exe ...
  ".venv\Scripts\python.exe" main.py
)
exit /b %ERRORLEVEL%
