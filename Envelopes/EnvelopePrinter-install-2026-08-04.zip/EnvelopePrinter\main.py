"""Launch the Envelope Printer GUI."""

from envelope_app.gui import run


if __name__ == "__main__":
    run()
