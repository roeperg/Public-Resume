# Envelope Printer — Installation Guide

Use this when installing from a **GitHub download** on a Windows PC that already has **Python** installed.

Printing uses **Microsoft Word**, so Word must also be installed on that PC.

---

## What you need

| Requirement | Notes |
|-------------|--------|
| Windows 10/11 | 64-bit recommended |
| Python 3.10 or newer | From [python.org](https://www.python.org/downloads/) — enable **Add python.exe to PATH** |
| Microsoft Word | Desktop Word app (used to create/print envelopes) |
| Brother (or other) printer | Online and visible in Windows |

You do **not** need to build an EXE for this install path.

---

## Download from GitHub

### Option A — Release zip (recommended)

1. Open the GitHub repository.
2. Go to **Releases**.
3. Download **`EnvelopePrinter-install-….zip`**.
4. Right-click the zip → **Extract All…** to a folder you can keep, for example:

   `C:\Users\<you>\Apps\EnvelopePrinter\`

### Option B — Source zip from the repo

1. On the repo page, click the green **Code** button → **Download ZIP**.
2. Extract it.
3. Open the extracted project folder (the one that contains `install.bat` and `main.py`).

---

## Install

1. Open the extracted folder.
2. Double-click **`install.bat`**.
3. Wait while it:
   - creates a local `.venv` folder
   - installs `ttkbootstrap`, `openpyxl`, `python-docx`, and `pywin32`
   - checks that imports work
   - creates a Desktop shortcut named **Envelope Printer**
4. When it says **Installation complete**, press a key to close the window.

If Python is missing or too old, the installer stops with an error message.

---

## Run

Either:

- Double-click **Envelope Printer** on the Desktop, or  
- Double-click **`run.bat`** in the install folder

Settings are saved in that same folder as `envelope_settings.json`.

---

## First-time use checklist

1. Confirm Word opens normally on that PC.
2. Start Envelope Printer.
3. Choose your Excel address file (**Browse…** / **Load**).
4. Select the printer (Refresh if needed).
5. Choose the envelope size.
6. Enter the return address.
7. Use **Preview Word** once, then **Print batch**.

---

## Uninstall

1. Double-click **`uninstall.bat`** in the install folder.
2. Type `YES` when asked.
3. This removes `.venv` and the Desktop shortcut.  
   Source files remain until you delete the folder yourself.

---

## Updating

1. Download the newer install zip from GitHub.
2. Extract it over the old folder **or** into a new folder.
3. Run **`install.bat`** again (safe to re-run; it reuses `.venv` and refreshes packages).

---

## Packaging a zip for GitHub (maintainer)

On the development PC, from the project folder:

```bat
pack_install.bat
```

That creates:

```text
release\EnvelopePrinter-install-YYYY-MM-DD.zip
```

Upload that file as a **GitHub Release** asset.

---

## Troubleshooting

| Problem | What to try |
|---------|-------------|
| `Python was not found on PATH` | Reinstall Python and check **Add python.exe to PATH**, then open a new Command Prompt |
| Import / pywin32 errors | Run `install.bat` again |
| Preview/print fails | Confirm Microsoft Word is installed and licensed; close stuck WINWORD.EXE in Task Manager |
| Wrong printer | Click **Refresh** in the app, or set the Brother as default in Windows |
| Shortcut missing | Start with `run.bat` in the install folder |

---

## Files created by install

```text
EnvelopePrinter\
  install.bat          ← run once to install
  uninstall.bat
  run.bat              ← launch the app
  requirements.txt
  main.py
  envelope_app\        ← application code
  .venv\               ← created by install.bat (not in the zip)
  envelope_settings.json  ← created after you use the app
```
