"""Build and print envelopes as Microsoft Word documents."""

from __future__ import annotations

import os
import time
from pathlib import Path

from docx import Document
from docx.enum.section import WD_ORIENT
from docx.enum.text import WD_BREAK
from docx.shared import Inches, Pt
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

from .config import ENVELOPE_SIZES, app_dir, envelope_inches
from .excel_reader import Address

try:
    import win32com.client
except ImportError:  # pragma: no cover
    win32com = None

# Layout anchors from the user's sample documents:
#   6.25 Sample.docx  → #6-1/4 style (3 blank lines, 2.5" recipient indent)
#   9.66 Sample.docx  → #9-5/8 style (4 blank lines, 3.8" recipient indent)
_REF_WIDTH_A_IN = 6.0  # our #6-1/4 long edge
_REF_WIDTH_B_IN = 9.625  # our #9-5/8 long edge
_REF_HEIGHT_A_IN = 3.5
_REF_HEIGHT_B_IN = 4.5
_REF_INDENT_A_IN = 2.5
_REF_INDENT_B_IN = 3.8
_REF_BLANK_A = 3
_REF_BLANK_B = 4

WORD_MARGIN_IN = 0.25


def word_layout_for_size(envelope_key: str) -> dict[str, float | int]:
    """
    Interpolate blank-line count and recipient indent from the two samples.

    #6-1/4 → 3 blanks, 2.5" indent
    #9-5/8 → 4 blanks, 3.8" indent
    Other sizes scale linearly by width (indent) and height (blanks).
    """
    width_in, height_in = envelope_inches(envelope_key)

    if abs(_REF_WIDTH_B_IN - _REF_WIDTH_A_IN) < 1e-9:
        t_w = 0.0
    else:
        t_w = (width_in - _REF_WIDTH_A_IN) / (_REF_WIDTH_B_IN - _REF_WIDTH_A_IN)

    if abs(_REF_HEIGHT_B_IN - _REF_HEIGHT_A_IN) < 1e-9:
        t_h = 0.0
    else:
        t_h = (height_in - _REF_HEIGHT_A_IN) / (_REF_HEIGHT_B_IN - _REF_HEIGHT_A_IN)

    indent_in = _REF_INDENT_A_IN + t_w * (_REF_INDENT_B_IN - _REF_INDENT_A_IN)
    blanks = int(round(_REF_BLANK_A + t_h * (_REF_BLANK_B - _REF_BLANK_A)))
    blanks = max(2, min(8, blanks))

    # Keep indent on the page (past left margin, before right margin).
    max_indent = max(0.0, width_in - 2 * WORD_MARGIN_IN - 1.0)
    indent_in = max(0.0, min(indent_in, max_indent))

    return {
        "width_in": width_in,
        "height_in": height_in,
        "blank_lines": blanks,
        "recipient_indent_in": indent_in,
        "margin_in": WORD_MARGIN_IN,
    }


def _set_run_font(run, size_pt: float = 11) -> None:
    run.font.name = "Calibri"
    run.font.size = Pt(size_pt)
    # Ensure East Asian / ASCII theme fonts don't override on Windows Word.
    r = run._element
    rPr = r.get_or_add_rPr()
    rFonts = rPr.find(qn("w:rFonts"))
    if rFonts is None:
        rFonts = OxmlElement("w:rFonts")
        rPr.insert(0, rFonts)
    rFonts.set(qn("w:ascii"), "Calibri")
    rFonts.set(qn("w:hAnsi"), "Calibri")
    rFonts.set(qn("w:cs"), "Calibri")


def _add_line(doc: Document, text: str, *, indent_in: float | None = None) -> None:
    paragraph = doc.add_paragraph()
    try:
        paragraph.style = doc.styles["No Spacing"]
    except KeyError:
        pass
    pf = paragraph.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)
    pf.line_spacing = 1.0
    if indent_in is not None and indent_in > 0:
        pf.left_indent = Inches(indent_in)
    run = paragraph.add_run(text)
    _set_run_font(run)


def _add_blank(doc: Document) -> None:
    paragraph = doc.add_paragraph()
    # Samples use Normal for spacer blanks between sender and recipient.
    pf = paragraph.paragraph_format
    pf.space_before = Pt(0)
    pf.space_after = Pt(0)


def _configure_section(section, width_in: float, height_in: float, margin_in: float) -> None:
    section.orientation = WD_ORIENT.LANDSCAPE
    section.page_width = Inches(width_in)
    section.page_height = Inches(height_in)
    section.left_margin = Inches(margin_in)
    section.right_margin = Inches(margin_in)
    section.top_margin = Inches(margin_in)
    section.bottom_margin = Inches(margin_in)


def _write_envelope_body(
    doc: Document,
    return_lines: list[str],
    recipient_lines: list[str],
    blank_lines: int,
    recipient_indent_in: float,
) -> None:
    for line in return_lines:
        _add_line(doc, line)

    for _ in range(blank_lines):
        _add_blank(doc)

    for line in recipient_lines:
        _add_line(doc, line, indent_in=recipient_indent_in)


def build_envelope_docx(
    addresses: list[Address],
    return_address: str,
    envelope_key: str,
    output_path: str | Path,
) -> Path:
    """Create a Word document with one landscape envelope page per address."""
    if not addresses:
        raise ValueError("No addresses selected.")

    layout = word_layout_for_size(envelope_key)
    width_in = float(layout["width_in"])
    height_in = float(layout["height_in"])
    margin_in = float(layout["margin_in"])
    blank_lines = int(layout["blank_lines"])
    indent_in = float(layout["recipient_indent_in"])

    return_lines = [line.strip() for line in return_address.splitlines() if line.strip()]
    if not return_lines:
        raise ValueError("Enter a return address.")

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    doc = Document()
    section = doc.sections[0]
    _configure_section(section, width_in, height_in, margin_in)

    # Drop the default empty paragraph Word inserts in a new document.
    body = doc.element.body
    for child in list(body):
        if child.tag == qn("w:p"):
            body.remove(child)

    for index, address in enumerate(addresses):
        if index > 0:
            breaker = doc.add_paragraph()
            breaker.paragraph_format.space_before = Pt(0)
            breaker.paragraph_format.space_after = Pt(0)
            breaker.add_run().add_break(WD_BREAK.PAGE)

        _write_envelope_body(
            doc,
            return_lines,
            address.lines(),
            blank_lines,
            indent_in,
        )

    doc.save(str(output))
    return output


def _docx_path() -> Path:
    return app_dir() / "last_envelope_print.docx"


def print_word_document(docx_path: str | Path, printer_name: str) -> None:
    """Print a .docx via Microsoft Word COM automation."""
    if win32com is None:
        raise RuntimeError("pywin32 is required to print from Microsoft Word.")

    path = Path(docx_path).resolve()
    if not path.is_file():
        raise FileNotFoundError(path)

    word = win32com.client.DispatchEx("Word.Application")
    word.Visible = False
    word.DisplayAlerts = 0
    doc = None
    try:
        # Prefer exact printer name from Windows.
        try:
            word.ActivePrinter = printer_name
        except Exception:
            # Some Word installs need the "on Ne0x:" suffix; try a fuzzy match.
            matched = _match_word_printer(word, printer_name)
            if matched:
                word.ActivePrinter = matched
            else:
                raise RuntimeError(
                    f"Could not select printer in Word: {printer_name}"
                ) from None

        doc = word.Documents.Open(str(path), ReadOnly=True, AddToRecentFiles=False)
        # Background=False waits until Word has handed the job to the spooler.
        doc.PrintOut(Background=False)
        # Brief pause so the spooler can accept the job before Word quits.
        time.sleep(1.0)
    finally:
        if doc is not None:
            try:
                doc.Close(SaveChanges=False)
            except Exception:
                pass
        try:
            word.Quit()
        except Exception:
            pass


def _match_word_printer(word, printer_name: str) -> str | None:
    """Find a Word ActivePrinter string that matches a Windows printer name."""
    target = printer_name.lower()
    try:
        # Word exposes installed printers via Application.ActivePrinter only as
        # the current one; Enumerate via WMI / win32print instead and try forms.
        import win32print

        flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
        names = [p["pPrinterName"] for p in win32print.EnumPrinters(flags, None, 2)]
    except Exception:
        names = [printer_name]

    candidates = []
    for name in names:
        if name.lower() == target or target in name.lower() or name.lower() in target:
            candidates.append(name)
            # Word often wants "Name on Ne01:"
            for port_suffix in ("", " on Ne01:", " on Ne00:", " on USB001:"):
                candidates.append(f"{name}{port_suffix}")

    for candidate in candidates:
        try:
            word.ActivePrinter = candidate
            return candidate
        except Exception:
            continue
    return None


def print_envelopes_word(
    addresses: list[Address],
    return_address: str,
    envelope_key: str,
    printer_name: str,
    keep_docx: Path | None = None,
) -> Path:
    """Build a Word envelope document and print it. Returns the .docx path."""
    docx_path = keep_docx if keep_docx is not None else _docx_path()
    build_envelope_docx(addresses, return_address, envelope_key, docx_path)
    print_word_document(docx_path, printer_name)
    return docx_path


def preview_envelopes_word(
    addresses: list[Address],
    return_address: str,
    envelope_key: str,
    keep_docx: Path | None = None,
) -> Path:
    """Build a Word envelope document and open it in the default app (Word)."""
    docx_path = keep_docx if keep_docx is not None else _docx_path()
    build_envelope_docx(addresses, return_address, envelope_key, docx_path)
    os.startfile(str(docx_path.resolve()))  # noqa: S606 - intentional on Windows
    return docx_path
