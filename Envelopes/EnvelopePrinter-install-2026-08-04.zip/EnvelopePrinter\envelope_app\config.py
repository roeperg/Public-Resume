"""Application constants and envelope size definitions."""

from __future__ import annotations

import sys
from pathlib import Path

# PDF/Word point helpers (no ReportLab dependency).
PT_PER_INCH = 72.0
MM_PER_INCH = 25.4


def app_dir() -> Path:
    """
    Writable directory for settings and local files.

    When frozen by PyInstaller, use the folder containing the EXE.
    Otherwise use the project root (parent of envelope_app/).
    """
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def _inches(height_in: float, width_in: float, label: str, win_paper: str = "") -> dict:
    """Build an envelope size entry (width = longer edge for landscape layout)."""
    return {
        "label": label,
        "width_in": width_in,
        "height_in": height_in,
        # Points kept for any PDF tooling that still reads these keys.
        "width": width_in * PT_PER_INCH,
        "height": height_in * PT_PER_INCH,
        "win_paper": win_paper,
    }


def _mm(height_mm: float, width_mm: float, label: str, win_paper: str = "") -> dict:
    """Build an envelope size entry from millimetres."""
    return _inches(height_mm / MM_PER_INCH, width_mm / MM_PER_INCH, label, win_paper)


# Envelope page sizes. width is the longer edge (landscape address layout).
ENVELOPE_SIZES = {
    "COM-10": _inches(4.125, 9.5, 'COM-10 (4.125" × 9.5")', "Env10"),
    "Monarch": _inches(3.875, 7.5, 'Monarch (3.875" × 7.5")', "EnvMonarch"),
    "DL": _mm(110, 220, "DL (110 × 220 mm)", "EnvDL"),
    "C5": _mm(162, 229, "C5 (162 × 229 mm)", "EnvC5"),
    # US regular commercial / invitation-style envelopes
    "No5": _inches(3.125, 5.5, '#5 Regular (3-1/8" × 5-1/2")'),
    "No6-1/4": _inches(3.5, 6.0, '#6-1/4 Regular (3-1/2" × 6")'),
    "No6-3/4": _inches(3.625, 6.5, '#6-3/4 Regular (3-5/8" × 6-1/2")'),
    "No7": _inches(3.75, 6.75, '#7 Regular (3-3/4" × 6-3/4")'),
    "No7-1/2": _inches(3.9375, 7.5, '#7-1/2 Regular (3-15/16" × 7-1/2")'),
    "No8-5/8": _inches(3.625, 8.625, '#8-5/8 Regular (3-5/8" × 8-5/8")'),
    "No9-5/8": _inches(4.5, 9.625, '#9-5/8 Regular (4-1/2" × 9-5/8")'),
    "No11": _inches(4.5, 10.375, '#11 Regular (4-1/2" × 10-3/8")'),
}

DEFAULT_ENVELOPE = "COM-10"

ENVELOPE_LABELS = {key: meta["label"] for key, meta in ENVELOPE_SIZES.items()}
ENVELOPE_KEYS_BY_LABEL = {meta["label"]: key for key, meta in ENVELOPE_SIZES.items()}

# Flexible header aliases for Excel columns (case-insensitive).
COLUMN_ALIASES = {
    "name": ("name", "full name", "fullname", "recipient", "to", "contact"),
    "address": ("address", "street", "street address", "addr", "address1", "address 1"),
    "city": ("city", "town"),
    "state": ("state", "st", "province", "region"),
    "zip": ("zip", "zipcode", "zip code", "postal", "postal code"),
}

PREFERRED_PRINTER_SUBSTRINGS = ("brother", "mfc-l8900", "l8900")

SETTINGS_FILENAME = "envelope_settings.json"


def settings_path() -> Path:
    return app_dir() / SETTINGS_FILENAME


def envelope_inches(envelope_key: str) -> tuple[float, float]:
    """Return (width_in, height_in) with width as the longer landscape edge."""
    if envelope_key not in ENVELOPE_SIZES:
        raise ValueError(f"Unknown envelope size: {envelope_key}")
    size = ENVELOPE_SIZES[envelope_key]
    return float(size["width_in"]), float(size["height_in"])
