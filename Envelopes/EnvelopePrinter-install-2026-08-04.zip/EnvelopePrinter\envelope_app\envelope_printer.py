"""Generate envelope PDFs and send them to a Windows printer."""

from __future__ import annotations

import os
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from contextlib import contextmanager
from pathlib import Path

from reportlab.lib.units import inch, mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

from .config import ENVELOPE_SIZES, PT_PER_INCH, app_dir
from .excel_reader import Address
from .printers import list_printers

try:
    import win32print
except ImportError:  # pragma: no cover
    win32print = None

# Legacy PDF layout defaults (optional tooling; not used by the Word GUI path).
DEFAULT_HORIZONTAL_SHIFT_IN = 0.0
DEFAULT_ROTATE_180 = True
LAYOUT_RETURN_LEFT = 0.25 * PT_PER_INCH
LAYOUT_RETURN_TOP = 0.25 * PT_PER_INCH
MEDIA_LEFT_PDF_MM = {"No6-1/4": 60.0, "No8-5/8": -30.0}


def media_left_pdf_mm(envelope_key: str) -> float:
    return float(MEDIA_LEFT_PDF_MM.get(envelope_key, 0.0))


def _temp_dir() -> Path:
    directory = Path(tempfile.gettempdir()) / "envelope_printer"
    directory.mkdir(parents=True, exist_ok=True)
    return directory


def _unique_pdf_path(prefix: str) -> Path:
    return _temp_dir() / f"{prefix}_{uuid.uuid4().hex}.pdf"


def _delayed_unlink(path: Path, attempts: int = 30, delay_sec: float = 2.0) -> None:
    """Delete a PDF after the print spooler releases it."""

    def worker() -> None:
        for _ in range(attempts):
            time.sleep(delay_sec)
            try:
                path.unlink(missing_ok=True)
                return
            except OSError:
                continue

    threading.Thread(target=worker, daemon=True).start()


def _register_fonts() -> tuple[str, str]:
    """Prefer a clean system font; fall back to Helvetica."""
    candidates = [
        (r"C:\Windows\Fonts\segoeui.ttf", r"C:\Windows\Fonts\segoeuib.ttf"),
        (r"C:\Windows\Fonts\arial.ttf", r"C:\Windows\Fonts\arialbd.ttf"),
        (r"C:\Windows\Fonts\calibri.ttf", r"C:\Windows\Fonts\calibrib.ttf"),
    ]
    for regular, bold in candidates:
        if Path(regular).exists() and Path(bold).exists():
            try:
                pdfmetrics.registerFont(TTFont("EnvSans", regular))
                pdfmetrics.registerFont(TTFont("EnvSans-Bold", bold))
                return "EnvSans", "EnvSans-Bold"
            except Exception:
                continue
    return "Helvetica", "Helvetica-Bold"


FONT_REGULAR, FONT_BOLD = _register_fonts()


def build_envelope_pdf(
    addresses: list[Address],
    return_address: str,
    envelope_key: str,
    output_path: str | Path,
    horizontal_shift_in: float = DEFAULT_HORIZONTAL_SHIFT_IN,
    rotate_180: bool = DEFAULT_ROTATE_180,
    debug: bool = False,
) -> Path:
    """Create a multi-page PDF with one envelope per address."""
    if envelope_key not in ENVELOPE_SIZES:
        raise ValueError(f"Unknown envelope size: {envelope_key}")

    size = ENVELOPE_SIZES[envelope_key]
    width = size["width"]
    height = size["height"]
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    return_lines = [line.strip() for line in return_address.splitlines() if line.strip()]
    shift_x = float(horizontal_shift_in) * inch
    # Per-size calibration: PDF x (mm) at the physical left edge of the envelope.
    media_comp_x = media_left_pdf_mm(envelope_key) * mm
    debug_line = None
    if debug:
        rot_label = "on" if rotate_180 else "off"
        left_mm = media_left_pdf_mm(envelope_key)
        debug_line = (
            f'{size["label"]}  |  nudge {float(horizontal_shift_in):.2f}"'
            f"  |  media {left_mm:+.0f}mm"
            f"  |  rotate 180°: {rot_label}"
        )
    pdf = canvas.Canvas(str(output), pagesize=(width, height))

    for address in addresses:
        _draw_envelope(
            pdf,
            width,
            height,
            return_lines,
            address.lines(),
            shift_x=shift_x,
            media_comp_x=media_comp_x,
            rotate_180=rotate_180,
            debug_line=debug_line,
        )
        pdf.showPage()

    pdf.save()
    return output


def _draw_envelope(
    pdf: canvas.Canvas,
    width: float,
    height: float,
    return_lines: list[str],
    recipient_lines: list[str],
    shift_x: float = 0.0,
    media_comp_x: float = 0.0,
    rotate_180: bool = False,
    debug_line: str | None = None,
) -> None:
    """Draw one envelope face; optionally rotate 180° for MP-tray feed."""
    if rotate_180:
        pdf.saveState()
        pdf.translate(width, height)
        pdf.rotate(180)

    _draw_envelope_face(
        pdf,
        width,
        height,
        return_lines,
        recipient_lines,
        shift_x=shift_x,
        media_comp_x=media_comp_x,
        debug_line=debug_line,
    )

    if rotate_180:
        pdf.restoreState()


def _draw_envelope_face(
    pdf: canvas.Canvas,
    width: float,
    height: float,
    return_lines: list[str],
    recipient_lines: list[str],
    shift_x: float = 0.0,
    media_comp_x: float = 0.0,
    debug_line: str | None = None,
) -> None:
    """Draw return + recipient on an upright envelope face."""
    small = height < 3.75 * inch
    return_font_size = 8 if small else 9
    recipient_font_size = 11 if small else 12
    line_gap_return = 11 if small else 12
    line_gap_recipient = 14 if small else 16

    # media_comp_x = PDF x of physical left edge (from calibration grid).
    x_adjust = media_comp_x

    if debug_line:
        debug_font_size = 7 if small else 8
        pdf.setFont(FONT_REGULAR, debug_font_size)
        pdf.drawCentredString(width / 2 + x_adjust, height - 0.18 * inch, debug_line)

    # Sender: 1/4" in from left, 1/4" down from top (baseline of first line).
    pdf.setFont(FONT_REGULAR, return_font_size)
    return_x = LAYOUT_RETURN_LEFT + x_adjust
    return_y = height - LAYOUT_RETURN_TOP
    for line in return_lines:
        pdf.drawString(return_x, return_y, line)
        return_y -= line_gap_return

    # Recipient: left-justified from page center; optional horizontal nudge.
    recip_x = (width / 2.0) + shift_x + x_adjust
    recip_y = height / 2.0
    for index, line in enumerate(recipient_lines):
        font = FONT_BOLD if index == 0 else FONT_REGULAR
        pdf.setFont(font, recipient_font_size)
        pdf.drawString(recip_x, recip_y, line)
        recip_y -= line_gap_recipient


def _bundled_sumatra() -> Path | None:
    """SumatraPDF bundled with the EXE or in tools/ during development."""
    if getattr(sys, "frozen", False):
        candidate = Path(sys._MEIPASS) / "SumatraPDF.exe"  # type: ignore[attr-defined]
        if candidate.is_file():
            return candidate
    candidate = Path(__file__).resolve().parent.parent / "tools" / "SumatraPDF.exe"
    if candidate.is_file():
        return candidate
    return None


def _sumatra_runtime_exe(source: Path) -> Path:
    """
    Return a SumatraPDF path safe to execute.

    When bundled inside a one-file EXE, copy to a writable temp folder so
    Sumatra can run and exit cleanly (it writes settings beside itself).
    """
    if getattr(sys, "frozen", False):
        runtime = _temp_dir() / "SumatraPDF.exe"
        if (
            not runtime.exists()
            or runtime.stat().st_size != source.stat().st_size
        ):
            shutil.copy2(source, runtime)
        return runtime
    return source


def _installed_sumatra() -> Path | None:
    """System-installed SumatraPDF."""
    candidates = [
        Path(os.environ.get("LOCALAPPDATA", "")) / "SumatraPDF/SumatraPDF.exe",
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))
        / "SumatraPDF/SumatraPDF.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"))
        / "SumatraPDF/SumatraPDF.exe",
    ]
    for path in candidates:
        if path.is_file():
            return path
    return None


def _find_acrobat() -> Path | None:
    """Locate Adobe Acrobat or Reader for /t silent printing."""
    candidates = [
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))
        / "Adobe/Acrobat DC/Acrobat/Acrobat.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"))
        / "Adobe/Acrobat Reader DC/Reader/AcroRd32.exe",
        Path(os.environ.get("PROGRAMFILES", r"C:\Program Files"))
        / "Adobe/Acrobat Reader DC/Reader/AcroRd32.exe",
        Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"))
        / "Adobe/Acrobat DC/Acrobat/Acrobat.exe",
    ]
    for path in candidates:
        if path.is_file():
            return path
    return None


@contextmanager
def _with_default_printer(printer_name: str):
    """Temporarily set the Windows default printer."""
    if win32print is None:
        raise RuntimeError("Setting default printer requires pywin32 on Windows.")
    previous = default_printer()
    win32print.SetDefaultPrinter(printer_name)
    try:
        yield
    finally:
        if previous:
            try:
                win32print.SetDefaultPrinter(previous)
            except Exception:
                pass


def _run_sumatra(exe: Path, path: Path, printer_name: str) -> None:
    runtime = _sumatra_runtime_exe(exe)
    pdf = str(path.resolve())
    if not Path(pdf).is_file():
        raise FileNotFoundError(f"PDF to print not found: {pdf}")

    # Sumatra requires the PDF path immediately after -print-to <printer>.
    # Options like -silent must come BEFORE -print-to, not between printer and file.
    base_args = [
        str(runtime),
        "-silent",
        "-exit-when-done",
        "-print-to",
        printer_name,
        pdf,
    ]
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    result = subprocess.run(
        base_args,
        capture_output=True,
        text=True,
        timeout=120,
        check=False,
        creationflags=creationflags,
    )
    if result.returncode == 0:
        return

    # Some drivers respond better when the target printer is also the default.
    with _with_default_printer(printer_name):
        fallback = [
            str(runtime),
            "-silent",
            "-exit-when-done",
            "-print-to-default",
            pdf,
        ]
        result = subprocess.run(
            fallback,
            capture_output=True,
            text=True,
            timeout=120,
            check=False,
            creationflags=creationflags,
        )
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "").strip()
        raise RuntimeError(
            detail or f"SumatraPDF exited with code {result.returncode}"
        )


def _run_acrobat(exe: Path, path: Path, printer_name: str) -> None:
    subprocess.Popen(
        [str(exe), "/t", str(path), printer_name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    time.sleep(5)


def print_pdf(pdf_path: str | Path, printer_name: str) -> None:
    """
    Send a PDF to the named Windows printer.

    Order: bundled SumatraPDF → installed SumatraPDF → Adobe Reader.
    """
    path = Path(pdf_path).resolve()
    if not path.exists():
        raise FileNotFoundError(path)

    printers = list_printers()
    if printer_name not in printers:
        raise ValueError(f"Printer not found: {printer_name}")

    attempts: list[tuple[str, Path]] = []
    runners: list = []

    bundled = _bundled_sumatra()
    if bundled:
        attempts.append(("SumatraPDF (bundled)", bundled))
        runners.append(_run_sumatra)

    installed = _installed_sumatra()
    if installed and installed != bundled:
        attempts.append(("SumatraPDF (installed)", installed))
        runners.append(_run_sumatra)

    acrobat = _find_acrobat()
    if acrobat:
        attempts.append(("Adobe Reader", acrobat))
        runners.append(_run_acrobat)

    errors: list[str] = []
    for (label, exe), runner in zip(attempts, runners):
        try:
            runner(exe, path, printer_name)
            return
        except Exception as exc:
            errors.append(f"{label}: {exc}")

    raise RuntimeError(
        "Could not print the PDF.\n\n"
        + "\n".join(errors)
        + "\n\nConfirm the Brother printer is online, then rebuild with "
        ".\\build_exe.bat if SumatraPDF is missing from the EXE."
    )


def _print_pdf_path() -> Path:
    """Fixed path for the latest print job (kept for verification/reprint)."""
    return app_dir() / "last_envelope_print.pdf"


def print_envelopes(
    addresses: list[Address],
    return_address: str,
    envelope_key: str,
    printer_name: str,
    keep_pdf: Path | None = None,
    horizontal_shift_in: float = DEFAULT_HORIZONTAL_SHIFT_IN,
    rotate_180: bool = DEFAULT_ROTATE_180,
    debug: bool = False,
) -> Path:
    """Build a PDF and print it. Returns the PDF path used."""
    if not addresses:
        raise ValueError("No addresses selected to print.")

    pdf_path = keep_pdf if keep_pdf is not None else _print_pdf_path()
    build_envelope_pdf(
        addresses,
        return_address,
        envelope_key,
        pdf_path,
        horizontal_shift_in=horizontal_shift_in,
        rotate_180=rotate_180,
        debug=debug,
    )
    if pdf_path.stat().st_size < 500:
        raise RuntimeError(f"Generated PDF looks empty: {pdf_path}")

    # Print the file we just wrote (absolute path avoids stale/temp confusion).
    print_pdf(pdf_path.resolve(), printer_name)
    return pdf_path


def build_calibration_grid_pdf(
    envelope_key: str,
    output_path: str | Path,
    rotate_180: bool = False,
    apply_media_compensation: bool = False,
) -> Path:
    """
    Build a calibration grid for the selected envelope size.

    Origin is the PDF bottom-left corner. Labels are (x_mm, y_mm) every 10 mm
    going right (+x) and up (+y).

    When apply_media_compensation is False (raw), marks show how the printer
    maps the page — use this to measure new sizes. When True, the same X
    shift used for address printing is applied so a corrected left edge
    should read near 0,*.
    """
    if envelope_key not in ENVELOPE_SIZES:
        raise ValueError(f"Unknown envelope size: {envelope_key}")

    size = ENVELOPE_SIZES[envelope_key]
    width = float(size["width"])
    height = float(size["height"])
    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)

    left_mm = media_left_pdf_mm(envelope_key) if apply_media_compensation else 0.0
    media_comp_x = left_mm * mm

    pdf = canvas.Canvas(str(output), pagesize=(width, height))
    if rotate_180:
        pdf.saveState()
        pdf.translate(width, height)
        pdf.rotate(180)

    if media_comp_x:
        pdf.saveState()
        pdf.translate(media_comp_x, 0)

    _draw_calibration_grid(
        pdf,
        width,
        height,
        size["label"],
        rotate_180,
        media_left_mm=left_mm,
        compensated=apply_media_compensation,
    )

    if media_comp_x:
        pdf.restoreState()
    if rotate_180:
        pdf.restoreState()

    pdf.showPage()
    pdf.save()
    return output


def _draw_calibration_grid(
    pdf: canvas.Canvas,
    width: float,
    height: float,
    label: str,
    rotate_180: bool,
    media_left_mm: float = 0.0,
    compensated: bool = False,
) -> None:
    """Draw border, 10 mm grid, and (x,y) mm labels from the bottom-left origin."""
    step = 10 * mm
    inset = 0.75  # keep border just inside the media box
    tick = 1.2 * mm

    pdf.setStrokeColorRGB(0, 0, 0)
    pdf.setFillColorRGB(0, 0, 0)
    pdf.setLineWidth(0.8)
    pdf.rect(inset, inset, width - 2 * inset, height - 2 * inset, stroke=1, fill=0)

    pdf.setLineWidth(0.35)
    x_vals: list[float] = []
    x = 0.0
    while x <= width + 0.01:
        x_vals.append(x)
        pdf.line(x, 0, x, height)
        x += step

    y_vals: list[float] = []
    y = 0.0
    while y <= height + 0.01:
        y_vals.append(y)
        pdf.line(0, y, width, y)
        y += step

    # Axis emphasis
    pdf.setLineWidth(1.0)
    pdf.line(0, 0, width, 0)
    pdf.line(0, 0, 0, height)

    font_size = 5.5 if height < 3.75 * inch else 6.5
    pdf.setFont(FONT_REGULAR, font_size)
    for gx in x_vals:
        for gy in y_vals:
            # Small cross at each grid point
            pdf.setLineWidth(0.45)
            pdf.line(gx - tick, gy, gx + tick, gy)
            pdf.line(gx, gy - tick, gx, gy + tick)

            x_mm = int(round(gx / mm))
            y_mm = int(round(gy / mm))
            text = f"{x_mm},{y_mm}"
            # Nudge label up/right of the point so the mark stays visible
            tx = gx + 0.6 * mm
            ty = gy + 0.6 * mm
            if tx + 12 > width:
                tx = gx - 12
            if ty + font_size > height:
                ty = gy - font_size - 0.4 * mm
            if tx < 0.5 * mm:
                tx = 0.5 * mm
            if ty < 0.5 * mm:
                ty = 0.5 * mm
            pdf.setFont(FONT_REGULAR, font_size)
            pdf.drawString(tx, ty, text)

    # Title / legend (top area of the face)
    pdf.setFont(FONT_BOLD, 7 if height < 3.75 * inch else 8)
    rot = "rotate 180° ON" if rotate_180 else "rotate 180° OFF"
    if compensated:
        mode = f"COMPENSATED media={media_left_mm:+.0f}mm"
    else:
        mode = "RAW (no media compensation)"
    title = (
        f"CALIBRATION  |  {label}  |  "
        f'{width / inch:.3f}" × {height / inch:.3f}"  |  {rot}  |  {mode}'
    )
    pdf.drawCentredString(width / 2, height - 4.5 * mm, title)
    pdf.setFont(FONT_REGULAR, 6 if height < 3.75 * inch else 7)
    if compensated:
        hint = (
            f"Grid shifted by {media_left_mm:+.0f}mm (same as address prints). "
            "Left edge of envelope should read near 0,* if calibration is correct."
        )
    else:
        hint = (
            "Origin (0,0) = PDF bottom-left. Labels are x_mm,y_mm every 10 mm. "
            "Use RAW to measure a new size; note PDF x at the physical left edge."
        )
    pdf.drawCentredString(width / 2, height - 8.5 * mm, hint)


def print_calibration_grid(
    envelope_key: str,
    printer_name: str,
    rotate_180: bool = False,
    apply_media_compensation: bool = False,
    keep_pdf: Path | None = None,
) -> Path:
    """Build and print a calibration grid. Returns the PDF path used."""
    pdf_path = keep_pdf if keep_pdf is not None else app_dir() / "last_calibration_grid.pdf"
    build_calibration_grid_pdf(
        envelope_key,
        pdf_path,
        rotate_180=rotate_180,
        apply_media_compensation=apply_media_compensation,
    )
    if pdf_path.stat().st_size < 500:
        raise RuntimeError(f"Generated PDF looks empty: {pdf_path}")
    print_pdf(pdf_path.resolve(), printer_name)
    return pdf_path


def preview_envelopes(
    addresses: list[Address],
    return_address: str,
    envelope_key: str,
    output_dir: str | Path | None = None,
    horizontal_shift_in: float = DEFAULT_HORIZONTAL_SHIFT_IN,
    rotate_180: bool = DEFAULT_ROTATE_180,
    debug: bool = False,
) -> Path:
    """Write a preview PDF and open it with the default viewer."""
    if output_dir is not None:
        pdf_path = Path(output_dir) / f"envelope_preview_{uuid.uuid4().hex}.pdf"
    else:
        pdf_path = _unique_pdf_path("preview")
    build_envelope_pdf(
        addresses,
        return_address,
        envelope_key,
        pdf_path,
        horizontal_shift_in=horizontal_shift_in,
        rotate_180=rotate_180,
        debug=debug,
    )
    sumatra = _bundled_sumatra() or _installed_sumatra()
    if sumatra:
        subprocess.Popen([str(sumatra), str(pdf_path)])
    else:
        os.startfile(str(pdf_path))  # noqa: S606 - intentional on Windows
    return pdf_path
